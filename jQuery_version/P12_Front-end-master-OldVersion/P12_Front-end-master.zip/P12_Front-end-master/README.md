# HRnet
Welcome to HRnet! This is our company's internal application to create and view employee records.

